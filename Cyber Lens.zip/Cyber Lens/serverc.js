// server.js
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const { Pool } = require('pg');

const app = express();
const port = 3000;

// ----------------------------------------------------------------------
// DATABASE CONNECTION POOL (Configure this section!)
// ----------------------------------------------------------------------
const pool = new Pool({
    user: 'forensic_user',          // <-- CHANGE THIS
    host: 'localhost',
    database: 'aethelred_db',       // <-- MUST MATCH YOUR DB NAME
    password: 'secure_password',    // <-- CHANGE THIS
    port: 5432,                     // PostgreSQL default port
});

pool.on('error', (err) => {
    console.error('FATAL: Unexpected error on idle database client', err);
    process.exit(-1);
});

// Middleware
app.use(bodyParser.json());
// Serve static files (index.html) from the 'public' directory
app.use(express.static(path.join(__dirname, 'public'))); 
console.log(`Serving static files from: ${path.join(__dirname, 'public')}`);


// ----------------------------------------------------------------------
// 1. DASHBOARD ROUTES (Metrics & Alerts)
// ----------------------------------------------------------------------
app.get('/api/dashboard/metrics', async (req, res) => {
    try {
        const metricsQuery = `
            SELECT 
                (SELECT COUNT(*) FROM Cases WHERE status = 'Investigating') AS active_cases,
                (SELECT SUM(ufdr_count) FROM Cases) AS ufdr_processed,
                (SELECT COUNT(*) FROM Alerts WHERE type = 'CRITICAL') AS critical_alerts,
                (SELECT AVG(risk_score) FROM Cases) AS avg_risk;
        `;
        const result = await pool.query(metricsQuery);
        // Ensure nulls are converted to 0 for frontend display safety
        const data = result.rows[0];
        data.avg_risk = parseFloat(data.avg_risk) || 0;
        res.json(data);
    } catch (err) {
        console.error('Error fetching metrics:', err.message);
        res.status(500).json({ message: 'Error fetching metrics from database.' });
    }
});
// Add this block after your existing Express routes (for example, after dashboard routes)
app.get('/api/case-graphs/:caseid', async (req, res) => {
  const caseid = req.params.caseid;
  try {
    // 1. Line chart: chat & call frequency
    const callsChats = await pool.query(
      `SELECT timestamp, 
        (SELECT COUNT(*) FROM Calls WHERE caseid=$1 AND suspectid=Chats.suspectid) AS call_count, 
        (SELECT COUNT(*) FROM Chats WHERE caseid=$1 AND suspectid=Chats.suspectid) AS chat_count
       FROM Chats WHERE caseid=$1`, [caseid]);
    // 2. Bar chart: top contacts
    const contactList = await pool.query(
      `SELECT receiverid, COUNT(*) AS contact_count 
        FROM Chats WHERE caseid=$1 
        GROUP BY receiverid 
        ORDER BY contact_count DESC LIMIT 10`, [caseid]);
    // 3. Pie chart: message/media/link/voice/deleted
    const chatContent = await pool.query(
      `SELECT 
        SUM(CASE WHEN type='message' THEN 1 ELSE 0 END) AS messages,
        SUM(CASE WHEN type='media' THEN 1 ELSE 0 END) AS media,
        SUM(CASE WHEN type='link' THEN 1 ELSE 0 END) AS links,
        SUM(CASE WHEN type='voice' THEN 1 ELSE 0 END) AS voice_notes,
        SUM(CASE WHEN deleted=TRUE THEN 1 ELSE 0 END) AS deleted
       FROM Chats WHERE caseid=$1`, [caseid]);
    // 4. Heatmap: suspicious keyword frequency
    const suspiciousHeatmap = await pool.query(
      `SELECT keyword, COUNT(*) AS freq 
        FROM SuspiciousMessages WHERE caseid=$1 GROUP BY keyword`, [caseid]);
    // 5. Probability chart: suspicious messages ratio
    const suspiciousStats = await pool.query(
      `SELECT COUNT(*) FILTER (WHERE is_suspicious) / COUNT(*)::float AS probability
        FROM Chats WHERE caseid=$1`, [caseid]);
    // 6. Radar chart: activity by hour/day and missing chats
    const activityRadar = await pool.query(
      `SELECT EXTRACT(HOUR FROM timestamp) AS hour, EXTRACT(DOW FROM timestamp) AS day, COUNT(*) AS count
        FROM Chats WHERE caseid=$1 GROUP BY hour, day`, [caseid]);
    const missingChats = await pool.query(
      `SELECT hour, day FROM (SELECT EXTRACT(HOUR FROM generate_series) AS hour, EXTRACT(DOW FROM generate_series) AS day 
            FROM generate_series((SELECT MIN(timestamp) FROM Chats WHERE caseid=$1),
                                 (SELECT MAX(timestamp) FROM Chats WHERE caseid=$1), '1 hour')) gs
       LEFT JOIN Chats ON EXTRACT(HOUR FROM Chats.timestamp)=gs.hour AND EXTRACT(DOW FROM Chats.timestamp)=gs.day
       WHERE Chats.timestamp IS NULL`, [caseid]);
    // 7. Node graph: networking links
    const networkingLinks = await pool.query(
      `SELECT senderid, receiverid, COUNT(*) AS comm_count 
        FROM Chats WHERE caseid=$1 GROUP BY senderid, receiverid`, [caseid]);
    res.json({
      callsChats: callsChats.rows,
      contactList: contactList.rows,
      chatContent: chatContent.rows,
      suspiciousHeatmap: suspiciousHeatmap.rows,
      suspiciousStats: suspiciousStats.rows,
      activityRadar: activityRadar.rows,
      missingChats: missingChats.rows,
      networkingLinks: networkingLinks.rows
    });
  } catch (error) {
    res.status(500).json({ error: 'Could not generate chart data.' });
  }
});



// ----------------------------------------------------------------------
// 2. NATURAL LANGUAGE QUERY ROUTE
// ----------------------------------------------------------------------
app.post('/api/query/nl', async (req, res) => {
    const { query } = req.body;
    
    // --- SIMULATION OF NLP PARSING ---
    let sqlQuery = '';
    let responseMessage = `AI: Executing query based on "${query}"...`;
    
    // Simple keyword-based routing for prototype
    if (query.toLowerCase().includes('person a') && query.toLowerCase().includes('person b')) {
        sqlQuery = `
            SELECT T1.timestamp, T3.name AS sender, T4.name AS receiver, T1.message
            FROM Chats T1
            JOIN Suspects T3 ON T1.sender_id = T3.suspect_id
            JOIN Suspects T4 ON T1.receiver_id = T4.suspect_id
            WHERE (T3.name = 'Person A' AND T4.name = 'Person B') OR (T3.name = 'Person B' AND T4.name = 'Person A')
            ORDER BY T1.timestamp DESC
            LIMIT 10;
        `;
        responseMessage = "AI: Found relevant communications between specified parties.";
    } else {
        res.json({ message: "AI: Query syntax recognized, but no prototype data matches this specific search.", results: [] });
        return;
    }
    
    try {
        const result = await pool.query(sqlQuery);
        res.json({ message: responseMessage, results: result.rows });
    } catch (err) {
        console.error('Error executing NL query:', err.message);
        res.status(500).json({ message: 'Database Query Error during NL search.' });
    }
});


// ----------------------------------------------------------------------
// 3. CASE DATA INSERTION ROUTE (UFDR Ingestion)
// ----------------------------------------------------------------------
app.post('/api/cases/ingest', async (req, res) => {
    const { case_id, suspect_name, data_type } = req.body;
    let client;
    
    if (!case_id || !suspect_name || !data_type) {
        return res.status(400).json({ message: 'Missing required data fields.' });
    }

    try {
        client = await pool.connect();
        await client.query('BEGIN'); // Start transaction

        // 1. Ensure Case Exists (or insert a new one)
        await client.query(
            'INSERT INTO Cases (case_id, status, risk_score) VALUES ($1, $2, $3) ON CONFLICT (case_id) DO UPDATE SET ufdr_count = Cases.ufdr_count + 1', 
            [case_id, 'Investigating', 50]
        );
        
        // 2. Insert Suspect (Assuming a new suspect/device for each ingestion for simplicity)
        const suspectResult = await client.query(
            'INSERT INTO Suspects (case_id, name) VALUES ($1, $2) RETURNING suspect_id', 
            [case_id, suspect_name]
        );
        const suspect_id = suspectResult.rows[0].suspect_id;

        // 3. Log the Data Ingestion (Simplified based on data_type)
        if (data_type === 'Chat Logs') {
            await client.query(
                'INSERT INTO Chats (case_id, sender_id, receiver_id, message, timestamp, language_mix) VALUES ($1, $2, $3, $4, NOW(), $5);',
                [case_id, suspect_id, suspect_id, `Initial UFDR chat ingestion for ${suspect_name}.`, 'English']
            );
        } else if (data_type === 'Images / Media') {
             await client.query(
                'INSERT INTO Media (case_id, suspect_id, file_path, is_tampered) VALUES ($1, $2, $3, $4);',
                [case_id, suspect_id, `/media/${case_id}/${suspect_name}_image.jpg`, false]
            );
        }
        
        // 4. Update UFDR count for existing cases (handled by ON CONFLICT, but doing it explicitly for clarity)
        const updateUfdrCount = await client.query('UPDATE Cases SET ufdr_count = ufdr_count + 1 WHERE case_id = $1 RETURNING ufdr_count', [case_id]);

        await client.query('COMMIT'); // End transaction

        res.status(200).json({ message: ` Data ingested. Case ${case_id} UFDR count: ${updateUfdrCount.rows[0].ufdr_count}` });

    } catch (err) {
        if (client) await client.query('ROLLBACK'); // Rollback transaction on error
        console.error('Ingestion transaction failed:', err.message);
        res.status(500).json({ message: 'Data ingestion failed due to database error.' });
    } finally {
        if (client) client.release();
    }
});


// ----------------------------------------------------------------------
// 4. MULTIMEDIA / FACE MATCH ROUTE
// ----------------------------------------------------------------------
app.get('/api/multimedia/face-matches', async (req, res) => {
    // This query finds face embeddings that appear in more than one case
    const sqlQuery = `
        SELECT T1.file_path, T1.case_id, T1.face_embedding
        FROM Media T1
        JOIN (
            SELECT face_embedding
            FROM Media
            GROUP BY face_embedding
            HAVING COUNT(DISTINCT case_id) > 1 AND face_embedding IS NOT NULL
            LIMIT 5 
        ) T2 ON T1.face_embedding = T2.face_embedding
        ORDER BY T1.face_embedding, T1.case_id;
    `;
    try {
        const result = await pool.query(sqlQuery);
        // Note: In a real system, the file_path would link to the actual image storage.
        res.json(result.rows);
    } catch (err) {
        console.error('Error fetching face matches:', err.message);
        res.status(500).json({ message: 'Server Error fetching multimedia intelligence.' });
    }
});


// Start the server
app.listen(port, () => {
    console.log(`\n--- Aethelred AI Backend running on http://localhost:${port} ---`);
    console.log('Ensure your PostgreSQL database is running and configured correctly.');
});

// Add this route into your server.js (after pool is defined).
// It accepts POST /api/alerts with JSON:
// { timestamp, case_id, type, rate_label, rate_percent, reporter, message }
// and inserts a row into Alerts. If you want to store reporter/rate in columns,
// see the optional ALTER TABLE SQL below.

app.post('/api/alerts', async (req, res) => {
  try {
    const { timestamp, case_id, type, rate_label, rate_percent, reporter, message } = req.body;
    if (!message || !type) {
      return res.status(400).json({ message: 'Missing required fields: type and message' });
    }
    // Build a combined message so the existing schema (case_id, type, message, timestamp) remains compatible.
    let composedMessage = message;
    if (reporter) composedMessage += ` (Reported by: ${reporter})`;
    if (rate_label || rate_percent !== undefined) {
      const pctText = rate_percent !== undefined ? ` ${rate_percent}%` : '';
      composedMessage += ` [Rate: ${rate_label || ''}${pctText}]`;
    }

    const ts = timestamp ? new Date(timestamp) : new Date();
    const insert = await pool.query(
      'INSERT INTO Alerts (case_id, type, message, timestamp) VALUES ($1, $2, $3, $4) RETURNING alert_id, case_id, type, message, timestamp',
      [case_id || null, type, composedMessage, ts]
    );

    res.status(201).json({ inserted: insert.rows[0] });
  } catch (err) {
    console.error('POST /api/alerts error:', err);
    res.status(500).json({ message: 'Failed to insert alert.' });
  }
});

// GET recent alerts
app.get('/api/alerts', async (req, res) => {
  const r = await pool.query('SELECT alert_id, case_id, type, message, timestamp, reporter, rate_label, rate_percent FROM alerts ORDER BY timestamp DESC LIMIT 200');
  res.json(r.rows);
});

// POST new alert
app.post('/api/alerts', async (req, res) => {
  const { timestamp, case_id, type, rate_label, rate_percent, reporter, message } = req.body;
  if (!type || !message) return res.status(400).json({ message: 'type and message required' });
  const ts = timestamp ? new Date(timestamp) : new Date();
  const insert = await pool.query(
    `INSERT INTO alerts (case_id, type, message, timestamp, reporter, rate_label, rate_percent)
     VALUES ($1,$2,$3,$4,$5,$6,$7)
     RETURNING alert_id, case_id, type, message, timestamp, reporter, rate_label, rate_percent`,
     [case_id || null, type, message, ts, reporter || null, rate_label || null, rate_percent || null]
  );
  res.status(201).json({ inserted: insert.rows[0] });
});
const express = require("express");
const multer = require("multer");
const fs = require("fs");
const upload = multer({ dest: "uploads/" });

app.post("/api/analyze-report", upload.single("dataset"), (req, res) => {
    const { caseId } = req.body;
    const filePath = req.file.path;

    // Read file (CSV/JSON/UFDR) - example

    // Simulated ML analysis (replace with real ML logic)
    const suspects = ["John Doe", "Kevin Smith"];
    const highRiskCount = 43;
    const keyword = "package drop";

    const report = `
Case ID: ${caseId}
Suspects: ${suspects.join(", ")}
Dataset: ${req.file.originalname}

Analysis:
The term "${keyword}" was detected ${highRiskCount} times across chat logs.
Multiple platforms reported the same keyword recently.
High-risk communications were observed among the suspects.

Recommendation:
Review high-risk communications immediately and document all related UFDRs.
    `.trim();

    // Delete uploaded file after analysis
    fs.unlinkSync(filePath);

    res.json({ report });
});

app.listen(3000, () => console.log("Server running on port 3000"));