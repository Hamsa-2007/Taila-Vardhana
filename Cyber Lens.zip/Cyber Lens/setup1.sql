-- setup.sql

-- 1. Create the database (if it doesn't exist)
-- CREATE DATABASE aethelred_db;

-- Connect to the new database: \c aethelred_db;

-- 2. CASES TABLE
CREATE TABLE Cases (
    case_id VARCHAR(10) PRIMARY KEY,
    status VARCHAR(50) NOT NULL,
    risk_score INT DEFAULT 50,
    ufdr_count INT DEFAULT 0
);

-- 3. SUSPECTS TABLE
CREATE TABLE Suspects (
    suspect_id SERIAL PRIMARY KEY,
    case_id VARCHAR(10) REFERENCES Cases(case_id),
    name VARCHAR(100),
    is_high_risk BOOLEAN DEFAULT FALSE
);

-- 4. CHATS TABLE (for NL Query)
CREATE TABLE Chats (
    chat_id SERIAL PRIMARY KEY,
    case_id VARCHAR(10) REFERENCES Cases(case_id),
    sender_id INT REFERENCES Suspects(suspect_id),
    receiver_id INT REFERENCES Suspects(suspect_id),
    message TEXT,
    timestamp TIMESTAMP DEFAULT NOW(),
    language_mix VARCHAR(50) -- e.g., 'Hinglish'
);

-- 5. ALERTS TABLE
CREATE TABLE Alerts (
    alert_id SERIAL PRIMARY KEY,
    case_id VARCHAR(10) REFERENCES Cases(case_id),
    type VARCHAR(50), -- e.g., 'CRITICAL', 'WARNING'
    message TEXT,
    timestamp TIMESTAMP DEFAULT NOW()
);

-- 6. MEDIA TABLE (for Multimedia Intelligence)
CREATE TABLE Media (
    media_id SERIAL PRIMARY KEY,
    case_id VARCHAR(10) REFERENCES Cases(case_id),
    suspect_id INT REFERENCES Suspects(suspect_id),
    file_path TEXT,
    is_tampered BOOLEAN DEFAULT FALSE,
    face_embedding TEXT -- Used for cross-case correlation
);

-- 7. Insert Initial Prototype Data for Testing
INSERT INTO Cases (case_id, status, risk_score, ufdr_count) VALUES
('C402', 'Investigating', 91, 5),
('C511', 'New Alert', 78, 1),
('C380', 'Closed', 20, 3);

INSERT INTO Suspects (case_id, name) VALUES
('C402', 'Person A'),
('C402', 'Person B'),
('C511', 'Person C');

INSERT INTO Chats (case_id, sender_id, receiver_id, message, language_mix) VALUES
('C402', 1, 2, 'Hey Person B, what time is the drop tomorrow?', 'English'),
('C402', 2, 1, 'We can meet at 10. Bring the usual package.', 'English'),
('C511', 3, 2, 'New meet location is secret.', 'English');

INSERT INTO Alerts (case_id, type, message) VALUES
('C402', 'CRITICAL', 'High volume of Foreign Calls detected.'),
('C402', 'CRITICAL', 'Suspect Person A added to high-risk watchlist.'),
(NULL, 'CRITICAL', 'New suspect identified via Cross-Case Face Match.');

-- Insert media with a matching face embedding across two cases
INSERT INTO Media (case_id, suspect_id, file_path, face_embedding) VALUES
('C402', 1, '/media/c402/pA_chat_1.jpg', 'EMBEDDING-ALPHA14-XYZ'),
('C511', 3, '/media/c511/pC_photo_1.jpg', 'EMBEDDING-ALPHA14-XYZ'), -- Same face ID
('C402', 1, '/media/c402/pA_selfie.jpg', 'EMBEDDING-BETA25-UVW');

ALTER TABLE Alerts ADD  reporter VARCHAR(150);
ALTER TABLE Alerts ADD  rate_label VARCHAR(50);
ALTER TABLE Alerts ADD  rate_percent INT;